from django.db import models

# Create your models here.
# class PokemonTable(models.Model):
